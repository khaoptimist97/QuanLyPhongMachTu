﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcAppMain.ViewModel
{
    public class PhieuThuTienViewModel
    {
        public string TenBenhNhan { get; set; }
        public int TienKham { get; set; }

        public int TienThuoc { get; set; }

        public int TongTien { get; set; }
    }
}