﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcAppMain.DTO
{
    public class BenhNhan
    {
        public string TenBenhNhan { get; set; }
    }
}